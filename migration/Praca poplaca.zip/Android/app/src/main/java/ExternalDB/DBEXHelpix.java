package ExternalDB;

import android.os.AsyncTask;
import android.util.Log;

import java.sql.Array;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import android.view.View;

import androidx.annotation.Nullable;

import pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca.R;

public class DBEXHelpix {

    private Connection con;


    public DBEXHelpix() {

        con = new EXConnection().CONN();

    }

    public static Connection getC() {
        return new EXConnection().CONN();

    }

    public void cl() {
        try {
            con.close();
        } catch (Exception e) {
            Log.v("#DBEX", "s");
        }

    }

    public void resum() {
        con = new EXConnection().CONN();

    }

    public int getUserIdByUsnameAndPass(String name, String pass) {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {

                return -1;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE usname=? AND password=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, name);
                smts.setString(2, pass);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return rsl.getInt("_id");

                } else {
                    return -1;
                }
            }

        } catch (SQLException e) {

            Log.e("#DBHLP1", "getUserIdByNameAndPass " + e.toString());

        }


        return -1;
    }

    public int getUserIdByEmailAndPass(String name, String pass) {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {
                return -1;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE email=? AND password=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, name);
                smts.setString(2, pass);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return rsl.getInt("_id");

                } else {
                    return -1;
                }
            }

        } catch (SQLException e) {

            Log.e("#DBHLP1", "getUserIdByNameAndPass " + e.toString());

        }


        return -1;
    }
    /*
     *
     *
     */


    public boolean CheckPassForUsername(String name, String pass) throws SQLException {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {
                return false;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE usname=? AND password=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, name);
                smts.setString(2, pass);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return true;
                } else {
                    return false;
                }
            }

        } catch (SQLException e) {
            Log.e("#DBHLP1", "CheckPassForUser " + e.toString());
            throw new SQLException(e.toString());


        }
    }

    public boolean CheckPassForEmail(String email, String pass) throws SQLException {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {
                return false;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE email=? AND password=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, email);
                smts.setString(2, pass);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return true;
                } else {
                    return false;
                }
            }

        } catch (SQLException e) {
            Log.e("#DBHLP1", "CheckPassForUser " + e.toString());
            throw new SQLException(e.toString());


        }
    }

    public boolean CheckUserByUsname(String name) {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {
                return false;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE usname=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, name);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return true;
                } else {
                    return false;
                }
            }

        } catch (SQLException e) {
            Log.e("#DBHLP1", "CheckUserByUsname " + e.toString());
            // throw new SQLException(e.toString());


        }
        return true;
    }

    /*public int CountEmpeeUserOffertsByUserID(int id) {

        String table_name = "employee_offert";
        try {
            con = getC();
            if (con == null) {
                return 1;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE =?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, id);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return 0;
                } else {
                    return 1;
                }
            }

        } catch (SQLException e) {
            Log.e("#DBHLP1", "CheckUserByUsname " + e.toString());
            // throw new SQLException(e.toString());


        }

        return 0;
    }*/

    public boolean CheckUserByEmail(String mail) {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {
                return false;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE email=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setString(1, mail);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return true;
                } else {
                    return false;
                }
            }

        } catch (SQLException e) {
            Log.e("#DBHLP1", "CheckUserByUsname " + e.toString());
            // throw new SQLException(e.toString());


        }
        return true;
    }


    public boolean isPhoneRegistered(int n) {
        String table_name = "employer_acc";
        String table_name2 = "employee_acc";
        try {
            con = getC();
            if (con == null) {
                return false;

            } else {
                String Q = "SELECT _id FROM " + table_name + " WHERE phone=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setInt(1, n);
                ResultSet rsl = smts.executeQuery();
                boolean A = true;
                boolean B = true;
                if (rsl.first()) {
                    A = true;
                } else {
                    A = false;
                }
                Q = "SELECT _id FROM " + table_name2 + " WHERE phone=?";
                smts = con.prepareStatement(Q);
                smts.setInt(1, n);
                rsl = smts.executeQuery();
                if (rsl.first()) {
                    B = true;
                } else {
                    B = false;
                }
                if (A && B) {
                    return true;
                }
                if (!A || !B) {
                    return false;
                }

            }

        } catch (SQLException e) {
            Log.e("#DBHLP1", "CheckUser " + e.toString());


        }
        return false;
    }


    public String[] getUserById(int id) {
        String table_name = "users";
        String[] data = new String[4];
        try {
            con = getC();
            if (con == null) {

                return null;

            } else {
                String Q = "SELECT * FROM " + table_name + " WHERE _id=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setInt(1, id);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    data[0] = Integer.toString(rsl.getInt("_id"));
                    data[1] = rsl.getString("usname");
                    data[2] = rsl.getString("email");
                    data[3] = Integer.toString(rsl.getInt("acc_type"));

                } else {
                    return null;
                }
                return data;
            }

        } catch (SQLException e) {

            Log.e("#DBHLP1", "getUserIdByNameAndPass " + e.toString());

        }


        return null;
    }


    public int getUserAccType(int id) {
        String table_name = "users";
        try {
            con = getC();
            if (con == null) {
                return -1;

            } else {
                String Q = "SELECT acc_type FROM " + table_name + " WHERE _id=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setInt(1, id);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    return rsl.getInt("acc_type");
                } else {
                    return -1;
                }
            }
        } catch (SQLException e) {

            Log.e("#DBHLP12", "getUserAccType " + e.toString());

        }
        return -1;
    }


    public String[][] getAllEmployerOfferts(int counted) {
        boolean isSuccess = false;
        String z = "";
        String table_name = "employer_offert";

        try {
            //  con = new EXConnection().CONN();
            if (con == null) {
                z = "Please check your internet connection";
            } else {
                String query = "select * from " + table_name + ";";
                Statement stmt = con.createStatement();
                // stmt.executeUpdate(query);
                ResultSet rs = stmt.executeQuery(query);
                String[][] e = new String[counted][17];
                int i = 0;
                while (rs.next()) {
                    isSuccess = true;
                    //  z = "Login successfull";
                    e[i][0] = (Integer.toString(rs.getInt("_id")));
                    e[i][1] = (rs.getString("title"));
                    e[i][2] = Integer.toString(rs.getInt("phone"));
                    e[i][3] = (rs.getString("city"));
                    e[i][4] = (rs.getString("address"));
                    e[i][5] = Integer.toString(rs.getInt("address_nr"));
                    e[i][6] = Integer.toString(rs.getInt("postcode"));
                    e[i][7] = Integer.toString(rs.getInt("type"));
                    switch (rs.getInt("type")) {
                        case 0: {
                            e[i][8] = "Umowa o dzieło";
                            e[i][9] = Integer.toString(rs.getInt("salary_o"));
                            e[i][10] = "";
                            e[i][11] = "Za wykonanie";
                            break;
                        }
                        case 1: {
                            e[i][8] = "Umowa o pracę/zlecenie";
                            e[i][9] = Integer.toString(rs.getInt("salary_a"));
                            e[i][10] = Integer.toString(rs.getInt("hours"));
                            e[i][11] = "Za godzinę*";
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                    e[i][12] = "";
                    e[i][13] = "";

                    /*e[i][9] = rs.getDate("date").toString();
                    e[i][10] = rs.getDate("date_from").toString();
                    e[i][11] = rs.getDate("date_to").toString();*/
                    e[i][14] = rs.getString("info");
                    e[i][15] = Integer.toString(getCategory(rs.getInt("cat_id")));
                    e[i][16] = Integer.toString(rs.getInt("acc_id"));
                    i++;

                }
                return e;
            }
        } catch (Exception ex) {
            isSuccess = false;
            z = "Exceptions" + ex;
            Log.v("#ER12", ex.toString());
        }
        return null;
    }

    public String[][] getSmallEmprOffertsByUserId(int i) {
        String table_name = "employer_offert";
        try {
            con = getC();
            if (con == null) {
                return null;
            } else {
                String q = "SELECT * FROM " + table_name + " WHERE acc_id=?";
                PreparedStatement stmt = con.prepareStatement(q);
                stmt.setInt(1, i);
                ResultSet rs = stmt.executeQuery();
                String[][] data = new String[CountEmployerOffertsById(i)][3];
                int k = 0;
                while (rs.next()) {
                    data[k][0] = Integer.toString(rs.getInt("_id"));
                    data[k][1] = rs.getString("title");
                    data[k][2] = rs.getString("info");
                    k++;
                }
                return data;
            }
        } catch (SQLException e) {
            Log.d("#DBEX8", e.toString());
            return null;
        }

    }

    public String[][] getSmallFolOffertsForEmpeByUserID(int i) {
        String tablename = "f_employee_offerts";
        String q1 = "SELECT empee_id FROM " + tablename + " WHERE user_id=?";
        try {
            con = getC();
            if (con == null) {
                Log.d("#DBHP22", "con null");
                return null;
            }
            PreparedStatement stmt = con.prepareStatement(q1);
            stmt.setInt(1, i);
            ResultSet rs = stmt.executeQuery();
            ArrayList<Integer> ar = new ArrayList();
            while (rs.next()) {

                ar.add(rs.getInt("empee_id"));
            }
            if (ar.size() != 0) {
                IArrayTransfer(ar);
            } else return null;
            String[][] T = new String[ar.size()][3];
            tablename = "employee_offert";
            for (int k = 0; k < ar.size(); k++) {
                q1 = "SELECT * FROM " + tablename + " WHERE _id=?";
                stmt = con.prepareStatement(q1);
                stmt.setInt(1, ar.get(k));
                rs = stmt.executeQuery();
                if (rs.first()) {
                    T[k][0] = Integer.toString(rs.getInt("_id"));
                    T[k][1] = rs.getString("title");
                    T[k][2] = rs.getString("title");
                }

            }
            if (T[0][0] != null) {
                return T;
            } else return null;

        } catch (SQLException e) {
            Log.d("#DBEX13", e.toString());
            return null;
        }

    }


    public String[][] getSmallEmpeOffertsByUserId(int i) {
        String table_name = "employee_offert";
        try {
            con = getC();
            if (con == null) {
                return null;
            } else {
                String q = "SELECT * FROM " + table_name + " WHERE acc_id=?";
                PreparedStatement stmt = con.prepareStatement(q);
                stmt.setInt(1, i);
                ResultSet rs = stmt.executeQuery();
                String[][] data = new String[CountEmployerOffertsById(i)][3];
                int k = 0;
                while (rs.next()) {
                    data[k][0] = Integer.toString(rs.getInt("_id"));
                    data[k][1] = rs.getString("title");
                    data[k][2] = Integer.toString(rs.getInt("cat_id"));
                    k++;
                }
                return data;
            }
        } catch (SQLException e) {
            return null;
        }

    }

    public int[] getIDsSmallEmpeOffertsFolByUserEmprID(int i) {
        String table_name = "f_employer_offerts";
        try {
            con = getC();
            if (con == null) {
                return null;
            } else {
                String q = "SELECT empe_id FROM " + table_name + " WHERE user_id=?";
                PreparedStatement stmt = con.prepareStatement(q);
                stmt.setInt(1, i);
                ResultSet rs = stmt.executeQuery();
                ArrayList<Integer> ar = new ArrayList();
                while (rs.next()) {
                    ar.add(rs.getInt("empe_id"));
                }
                if (ar.size() != 0) {
                    return IArrayTransfer(ar);
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {
        }
        return null;
    }

    public String[][] getSmallEmpeOffertsFolForUser(int[] e) {


        return null;
    }

    public String[][] getSmallFolOffertsForEmprByUserID(int id) {


        return null;
    }

    public int CountEmployerOffertsById(int i) {
        int k = 0;
        String tablename = "employer_offert";
        try {
            con = getC();
            if (con == null) {
                throw new SQLException();
            } else {
                String queryl = "SELECT COUNT(_id) FROM " + tablename + " WHERE acc_id=?;";
                PreparedStatement stmtl = con.prepareStatement(queryl);
                //con.prepareStatement()
                stmtl.setInt(1, i);
                ResultSet rsl = stmtl.executeQuery();
                if (rsl.next()) {
                    i++;
                } else {
                    return 0;
                }
                return i;
            }

//
//                String query="SELECT whatever FROM users;";
//                Statement stmt = con.createStatement();
//                ResultSet rs=stmt.executeQuery(query);
//
//                while(rs.next()){
//                    whatever.add(rs.getString(3));}
//


        } catch (SQLException e) {
            Log.e("ERROR1", e.toString());
        }

        return k;
    }


    public String[][] getAllEmployerOffertsASC() {
        boolean isSuccess = false;
        String z = "";
        String table_name = "employer_offerts";

        try {
            //  con = new EXConnection().CONN();
            if (con == null) {
                z = "Please check your internet connection";
            } else {
                String query = "select * from " + table_name + " ORDER BY nazwa ASC;";
                Statement stmt = con.createStatement();
                // stmt.executeUpdate(query);
                ResultSet rs = stmt.executeQuery(query);
                String[][] e = new String[countEmployerOfferts()][2];
                int i = 0;
                while (rs.next()) {
                    isSuccess = true;
                    //  z = "Login successfull";
                    e[i][0] = (Integer.toString(rs.getInt(1)));
                    e[i][1] = (rs.getString(2));

                    i++;
                }

                return e;
            }
        } catch (Exception ex) {
            isSuccess = false;
            z = "Exceptions" + ex;
            Log.v("#ER12", ex.toString());
        }

        return null;
    }


    public int getCategory(int i) {

        String table_name = "category";
        try {
            //  con = new EXConnection().CONN();
            if (con == null) {

            } else {
                String query = "select int from " + table_name + " where _id='" + i + "';";
                Statement stmt = con.createStatement();
                // stmt.executeUpdate(query);
                ResultSet rs = stmt.executeQuery(query);
                if (rs.first()) {
                    return rs.getInt("int");
                } else {
                    return 0;
                }
            }
        } catch (Exception ex) {
            Log.v("#ER14", ex.toString());
        }

        return 0;
    }


    public int countEmployerOfferts() {
        int i = 0;
        String table_name = "employer_offert";
        try {

            if (con == null) {
                throw new SQLException();
            } else {
                String queryl = "SELECT COUNT(_id) FROM " + table_name + "";
                Statement stmtl = con.createStatement();
                //con.prepareStatement()
                ResultSet rsl = stmtl.executeQuery(queryl);
                //int na string !
                //con.commit();

                if (rsl.first()) {
                    i = rsl.getInt(1);
                    return i;
                } else {
                    return 0;
                }

            }

//
//                String query="SELECT whatever FROM users;";
//                Statement stmt = con.createStatement();
//                ResultSet rs=stmt.executeQuery(query);
//
//                while(rs.next()){
//                    whatever.add(rs.getString(3));}
//


        } catch (SQLException e) {
            Log.e("ERROR1", e.toString());
        }

        return i;

    }


    //
    public int countUserOffertsEMPRWhereId(int id) {
        int i = 0;

        try {

            if (con == null) {
                throw new SQLException();
            } else {
                String queryl = "SELECT COUNT(_id) FROM employer_offert WHERE acc_id=?";

                PreparedStatement smts = con.prepareStatement(queryl);
                smts.setInt(1, id);
                ResultSet rsl = smts.executeQuery();

                if (rsl.first()) {
                    i = rsl.getInt(1);
                    Log.v("#DBEXEMPR", Integer.toString(i));
                } else {
                    return 0;
                }
                return i;
            }
//
//                String query="SELECT whatever FROM users;";
//                Statement stmt = con.createStatement();
//                ResultSet rs=stmt.executeQuery(query);
//
//                while(rs.next()){
//                    whatever.add(rs.getString(3));}
//
        } catch (SQLException e) {
            Log.e("ERROR1", e.toString());
        }
        return i;
    }

    public int countUserOffertsEMPEWhereId(int id) {
        int i = 0;

        try {

            if (con == null) {
                throw new SQLException();
            } else {
                String queryl = "SELECT COUNT(_id) FROM employee_offert WHERE acc_id=?";

                PreparedStatement smts = con.prepareStatement(queryl);
                smts.setInt(1, id);
                ResultSet rsl = smts.executeQuery();

                if (rsl.first()) {
                    i = rsl.getInt(1);
                } else {
                    return 0;
                }
                return i;
            }

//
//                String query="SELECT whatever FROM users;";
//                Statement stmt = con.createStatement();
//                ResultSet rs=stmt.executeQuery(query);
//
//                while(rs.next()){
//                    whatever.add(rs.getString(3));}
//


        } catch (SQLException e) {
            Log.e("ERROR1", e.toString());
        }

        return i;

    }

    public String[] SArrayTransfer(ArrayList<String> Queed) {
        String[] temp = new String[Queed.size()];
        for (int ITERATOR = 0; ITERATOR < temp.length; ITERATOR++) {
            temp[ITERATOR] = Queed.get(ITERATOR);
        }
        return temp;
    }

    public int[] IArrayTransfer(ArrayList<Integer> Queed) {
        int[] temp = new int[Queed.size()];
        for (int ITERATOR = 0; ITERATOR < temp.length; ITERATOR++) {
            temp[ITERATOR] = Queed.get(ITERATOR);
        }
        return temp;
    }

    public String[] getEmployerOffertById(int id) {

        String table_name = "employer_offert";

        try {
            con = getC();
            if (con == null) {
                return null;

            } else {
                String Q = "SELECT * FROM " + table_name + " WHERE _id=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setInt(1, id);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    switch (rsl.getInt("type")) {
                        case 0: {
                            String[] data = new String[10];
                            data[0] = Integer.toString(rsl.getInt(1));
                            data[1] = rsl.getString(2);
                            data[2] = Integer.toString(rsl.getInt(3));
                            data[3] = rsl.getString(4);
                            data[4] = rsl.getString(5);
                            data[5] = Integer.toString(rsl.getInt(6));
                            data[6] = Integer.toString(rsl.getInt(7));
                            data[7] = Integer.toString(rsl.getInt(8));
                            data[8] = Integer.toString(rsl.getInt(9));
                            data[9] = rsl.getString(16);
                            // week no
                            return data;
                        }
                        case 1: {
                            String[] data = new String[11];
                            data[0] = Integer.toString(rsl.getInt(1));
                            data[1] = rsl.getString(2);
                            data[2] = Integer.toString(rsl.getInt(3));
                            data[3] = rsl.getString(4);
                            data[4] = rsl.getString(5);
                            data[5] = Integer.toString(rsl.getInt(6));
                            data[6] = Integer.toString(rsl.getInt(7));
                            data[7] = Integer.toString(rsl.getInt(8));
                            //
                            data[8] = Integer.toString(rsl.getInt(10));
                            // week
                            // d
                            data[9] = Integer.toString(rsl.getInt(15));
                            data[10] = rsl.getString(16);
                            return data;
                        }
                        default: {
                            break;
                        }

                    }

                } else {
                    return null;
                }
            }
        } catch (SQLException e) {
            Log.e("#DBHLP1", "getEmployerOffertById" + e.toString());
        }
        return null;
    }

    public String[] getEmployeeOffertById(int id) {

        String table_name = "employee_offert";
        String[] data = new String[5];
        try {
            con = getC();
            if (con == null) {
                return null;

            } else {
                String Q = "SELECT * FROM " + table_name + " WHERE _id=?";
                PreparedStatement smts = con.prepareStatement(Q);
                smts.setInt(1, id);
                ResultSet rsl = smts.executeQuery();
                if (rsl.first()) {
                    data[0] = Integer.toString(rsl.getInt(1));
                    data[1] = rsl.getString(2);
                    return data;
                } else {
                    return null;
                }
            }
        } catch (SQLException e) {

            Log.e("#DBHLP1", "CheckEmailInUser " + e.toString());

        }
        return null;
    }


    public boolean insertUserEmprCompA(String usname, String email, String pass, int type,
                                       String name, String surname, int phone, String city, int nip, String cname, String address,
                                       int address_nr) {
        try {
            con = getC();
            if (con == null) {
                return false;
            } else {

                String queryl = "INSERT INTO users (usname,email,password,acc_type) VALUES (?,?,?,?);";
                PreparedStatement stmtl = con.prepareStatement(queryl);
                stmtl.setString(1, usname);
                stmtl.setString(2, email);
                stmtl.setString(3, pass);
                stmtl.setInt(4, type);

                int rsl = stmtl.executeUpdate();

                Log.d("#in1", "insert into user result :" + rsl);
                if (rsl >= 0) {
                    queryl = "SELECT _id FROM users WHERE usname=?";
                    stmtl = con.prepareStatement(queryl);
                    stmtl.setString(1, usname);
                    ResultSet rs1 = stmtl.executeQuery();
                    int rs = -1;
                    int rss = -1;
                    if (rs1.first()) {
                        rs = rs1.getInt("_id");
                        rss = rs;
                        Log.d("#in2", "select id :" + rs);
                        queryl = "INSERT INTO employer_acc (name, surname, phone, city, NIP, c_name, address, address_nr, acc_id) VALUES ( ? , ? , ? , " +
                                " ?, ? , ?, ? , ? , ? );";
                        stmtl = con.prepareStatement(queryl);
                        stmtl.setString(1, name);
                        stmtl.setString(2, surname);
                        stmtl.setInt(3, phone);
                        stmtl.setString(4, city);
                        stmtl.setInt(5, nip);
                        stmtl.setString(6, cname);
                        stmtl.setString(7, address);
                        stmtl.setInt(8, address_nr);
                        stmtl.setInt(9, rs);
                        rsl = stmtl.executeUpdate();
                        Log.d("#in3", "insert into employer:" + rsl);
                        if (rsl >= 0) {

                            rs = getEmprIdByUserID(rs);
                            Log.d("#in4", "getEmprIdByUserID" + rs);
                            queryl = "UPDATE users SET acc_id=? WHERE _id=?";
                            stmtl = con.prepareStatement(queryl);
                            stmtl.setInt(1, rs);
                            stmtl.setInt(2, rss);
                            rsl = stmtl.executeUpdate();
                            Log.d("#in4", "getEmprIdByUserID" + rsl);
                            if (rsl >= 0) {

                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

            }
        } catch (java.sql.SQLException e) {
            Log.d("#DBEX2", e.toString());
        }
        return false;
    }

    public int getEmprIdByUserID(int id) {
        String tablename = "employer_offert";
        try {
            con = getC();
            if (con == null) {
                return -1;
            } else {
                String queryl = "SELECT acc_id FROM " + tablename + " WHERE _id=?";
                PreparedStatement stmtl = con.prepareStatement(queryl);
                stmtl.setInt(1, id);
                ResultSet rsl = stmtl.executeQuery();
                if (rsl.first()) {
                    return rsl.getInt("acc_id");
                } else return 0;
            }
        } catch (java.sql.SQLException e) {
            Log.d("#DBEX5", e.toString());
        }


        return -1;
    }

    public boolean insertUserEmprComp(String usname, String email, String pass, int type,
                                      String name, String surname, int phone, String city, int nip, String cname, String address,
                                      int address_nr) {
        try {
            con = getC();
            if (con == null) {
                return false;
            } else {
                String queryl = "INSERT INTO users (usname,email,password,acc_type) VALUES (?,?,?,?);";
                PreparedStatement stmtl = con.prepareStatement(queryl);
                stmtl.setString(1, usname);
                stmtl.setString(2, email);
                stmtl.setString(3, pass);
                stmtl.setInt(4, type);

                int rsl = stmtl.executeUpdate();

                Log.d("#in1", "insert into user result :" + rsl);
                if (rsl >= 0) {
                    queryl = "SELECT _id FROM users WHERE usname=?";
                    stmtl = con.prepareStatement(queryl);
                    stmtl.setString(1, usname);
                    ResultSet rs1 = stmtl.executeQuery();
                    int rs = -1;
                    if (rs1.first()) {
                        rs = rs1.getInt("_id");

                        queryl = "INSERT INTO employer_acc (name, surname, phone, city, NIP, c_name, address, address_nr, acc_id) VALUES ( ? , ? , ? , " +
                                " ?, ? , ?, ? , ? , ? );";
                        stmtl = con.prepareStatement(queryl);
                        stmtl.setString(1, name);
                        stmtl.setString(2, surname);
                        stmtl.setInt(3, phone);
                        stmtl.setString(4, city);
                        stmtl.setInt(5, nip);
                        stmtl.setString(6, cname);
                        stmtl.setString(7, address);
                        stmtl.setInt(8, address_nr);
                        stmtl.setInt(9, rs);
                        rsl = stmtl.executeUpdate();
                        if (rsl >= 0) {
                            Log.d("#in2", "insert into user result :" + rs1);
                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

            }
        } catch (java.sql.SQLException e) {
            Log.d("#DBEX2", e.toString());
        }
        return false;
    }


    public boolean insertUserEmpe(String usname, String email, String pass, int type,
                                  String name, String surname, int phone, int idnr) {
        try {
            con = getC();
            if (con == null) {
                return false;
            } else {
                String queryl = "INSERT INTO users (usname,email,password,acc_type) VALUES (?,?,?,?);";
                PreparedStatement stmtl = con.prepareStatement(queryl);
                stmtl.setString(1, usname);
                stmtl.setString(2, email);
                stmtl.setString(3, pass);
                stmtl.setInt(4, type);
                int rsl = stmtl.executeUpdate();

                Log.d("#in11", "insert into user result :" + rsl);
                if (rsl >= 0) {
                    queryl = "SELECT _id FROM users WHERE usname=?";
                    stmtl = con.prepareStatement(queryl);
                    stmtl.setString(1, usname);
                    ResultSet rs1 = stmtl.executeQuery();
                    int rs = -1;
                    Log.d("#in22", "select result :" + rs1);
                    if (rs1.first()) {
                        rs = rs1.getInt("_id");
                        queryl = "INSERT INTO employee_acc (name, surname, phone, idnr,  acc_id) VALUES ( ? , ? ,? , ? , ?)";
                        stmtl = con.prepareStatement(queryl);
                        stmtl.setString(1, name);
                        stmtl.setString(2, surname);
                        stmtl.setInt(3, phone);
                        stmtl.setInt(3, idnr);
                        stmtl.setInt(4, rs);
                        rsl = stmtl.executeUpdate();
                        if (rsl >= 0) {
                            Log.d("#in33", "insert into employee_acc:" + rs1);
                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

            }
        } catch (java.sql.SQLException e) {
            Log.d("#DBEX2", e.toString());
        }
        return false;
    }


    public boolean insertUserEmpr(String usname, String email, String pass, int type,
                                  String name, String surname, int phone, String city) {
        try {
            con = getC();
            if (con == null) {
                return false;
            } else {
                String queryl = "INSERT INTO users (usname,email,password,acc_type) VALUES (?,?,?,?);";
                PreparedStatement stmtl = con.prepareStatement(queryl);
                stmtl.setString(1, usname);
                stmtl.setString(2, email);
                stmtl.setString(3, pass);
                stmtl.setInt(4, type);
                int rsl = stmtl.executeUpdate();

                Log.d("#in33", "insert into user result :" + rsl);
                if (rsl >= 0) {

                    queryl = "SELECT _id FROM users WHERE usname=?";
                    stmtl = con.prepareStatement(queryl);
                    stmtl.setString(1, usname);
                    ResultSet rs1 = stmtl.executeQuery();
                    int rs = -1;
                    Log.d("#in44", "insert into user result :" + rs);

                    if (rs1.first()) {
                        rs = rs1.getInt("_id");
                        queryl = "INSERT INTO employer_acc (name, surname, phone, city, acc_id) VALUES ( ? , ? , ? , ?, ?)";
                        stmtl = con.prepareStatement(queryl);
                        stmtl.setString(1, name);
                        stmtl.setString(2, surname);
                        stmtl.setInt(3, phone);
                        stmtl.setString(4, city);
                        stmtl.setInt(5, rs);
                        rsl = stmtl.executeUpdate();
                        Log.d("#in55", "insert into user result :" + rsl);
                        if (rsl >= 0) {

                            return true;
                        } else {
                            return false;
                        }
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

            }
        } catch (java.sql.SQLException e) {
            Log.d("#DBEX2", e.toString());
        }
        return false;
    }


    public boolean insertEmprOffert(int id, String title, int phone, String city, String address, int address_nr, int postcode,
                                    int type, int salary, int week_id, Date date, Date datefrom, Date dateto, int hours, String info, int cat_id) {


        String k = "INSERT INTO employer_offert(title, phone, city, address, address_nr, post-code, type, salary_a, date, date_from, date_to, hours, info, cat_id, acc_id) " +
                "VALUES(?, ?, ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";


        return false;
    }


    public boolean insertEmprOffertWithoutWeek(int id, String title, int phone, String city, String address, int address_nr, int postcode,
                                               int type, int salary, String info, int cat_id) {
        String tablename = "employer_offert";
        try {
            con = getC();
            if (con == null) {
                return false;
            } else {
                String q = "INSERT INTO " + tablename + " (title, phone, city, address, address_nr, postcode, type, salary_o, info, cat_id, acc_id) VALUES(?, ?, ? , ?, ?, ?, ?, ?, ?, ?, ? );";
                PreparedStatement stmtl = con.prepareStatement(q);
                stmtl.setString(1, title);
                stmtl.setInt(2, phone);
                stmtl.setString(3, city);
                stmtl.setString(4, address);
                stmtl.setInt(5, address_nr);
                stmtl.setInt(6, postcode);
                stmtl.setInt(7, type);
                stmtl.setInt(8, salary);
                //                stmtl.setDate(9, date);
                //stmtl.setString(9, datefrom);
                //stmtl.setString(10, dateto);
                stmtl.setString(9, info);
                stmtl.setInt(10, cat_id);
                stmtl.setInt(11, id);
                int rsl = stmtl.executeUpdate();
                Log.d("#in33", "insert into employer_offert result :" + rsl);
                if (rsl >= 0) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            Log.d("#DBEX6", e.toString());
        }
        return false;
    }


    public boolean SelectEMPROffertsByCity(String city) {

        String tablename = "employer_offert";
        try {
            con = getC();
            if (con == null) {
                return false;
            } else {
                String q = "SELECT * FROM " + tablename + " WHERE city=?";
                PreparedStatement stmtl = con.prepareStatement(q);
                stmtl.setString(1, city);
                ResultSet rs = stmtl.executeQuery();
                String data[][]= new String[CountEMPROffertsByCity(city)][12];
                int i=0;
                while(rs.next()){
                    data[i][1] = Integer.toString(rs.getInt(1)   );
                    data[i][2] =  rs.getString("title")  ;
                    data[i][3] =  Integer.toString(rs.getInt("phone"));
                    data[i][4] =    Integer.toString(rs.getInt("phone"));;
                    data[i][5] =    Integer.toString(rs.getInt("phone"));;
                }
                i++;
            }
        } catch (SQLException e) {

        }
        return false;
    }

    public String[][] SelectEMPROffertsByFilters(@Nullable String city, @Nullable String catID, @Nullable String Salary,
                                                 @Nullable String type){
        String tablename = "employer_offert";
        boolean tabs[] = new boolean[4] ;
        try {
            con = getC();
            if (con == null) {
                return null;
            } else {
                if (city!=null)
                { tabs[0]=true;}else { tabs[1]=false; }
                if (catID!=null)
                { tabs[1]=true;}else { tabs[1]=false; }
                if (Salary!=null)
                { tabs[2]=true;}else { tabs[2]=false; }
                if (type!=null)
                { tabs[3]=true;}else { tabs[1]=false; }
            String ql = "SELECT * FROM "+tablename+"";
                int k =0;
                for(int i=0; i< tabs.length; i++){
                    if(tabs[i])
                        k++;
                  }
                String[] tabb = new String[k];
                if (city!=null)
                { tabb[0]=city;}
                if (catID!=null)
                { tabb[1]=catID;}
                if (Salary!=null)
                { tabb[2]=Salary;}
                if (type!=null)
                { tabb[3]=type;}
                int g=k;
                for(int i=0; i< tabs.length;i++){
                    if(tabs[i]&&i==0){
                        ql+=" WHERE city=? ";
                        if(k!=0){
                            ql+= " AND ";
                        }
                    }else if (tabs[i]&&i==1){
                        ql+=" WHERE cat_id=? ";
                        if(k!=0){
                            ql+= " AND ";
                        }
                    }
                    else if (tabs[i]&&i==2){
                        ql+=" WHERE Salary=? ";
                        if(k!=0){
                        ql+= " AND ";
                        }
                    }
                    else if (tabs[i]&&i==3){
                        ql+=" WHERE type=? ";
                        g++;
                    }
                    k--;
                }
                int h=1;
                PreparedStatement stmtl = con.prepareStatement(ql);
                for (int i=0; i<tabs.length;i++){
                    if(tabs[i]&&i==0){
                        if(h<g){
                            stmtl.setString(h, city);h++; }}
                    if(tabs[i]&&i==1){
                        if(h<g){
                            stmtl.setInt(h, Integer.parseInt(catID));h++;
                        }}
                    if(tabs[i]&&i==2){
                        if(h<g){
                            stmtl.setInt(h, Integer.parseInt(Salary));h++;
                    }  }
                    if(tabs[i]&&i==3){
                        if(h<g){
                            stmtl.setInt(h, Integer.parseInt(type));h++;
                    }  }
                    }
                ResultSet rs = stmtl.executeQuery();

                String e[][]= new String[CountEMPROffertsWithFiltersCity(ql, tabb)][12];
                int i=0;
                while(rs.next()){
                    e[i][0] = (Integer.toString(rs.getInt("_id")));
                    e[i][1] = (rs.getString("title"));
                    e[i][2] = Integer.toString(rs.getInt("phone"));
                    e[i][3] = (rs.getString("city"));
                    e[i][4] = (rs.getString("address"));
                    e[i][5] = Integer.toString(rs.getInt("address_nr"));
                    e[i][6] = Integer.toString(rs.getInt("postcode"));
                    e[i][7] = Integer.toString(rs.getInt("type"));
                    switch (rs.getInt("type")) {
                        case 0: {
                            e[i][8] = "Umowa o dzieło";
                            e[i][9] = Integer.toString(rs.getInt("salary_o"));
                            e[i][10] = "";
                            e[i][11] = "Za wykonanie";
                            break;
                        }
                        case 1: {
                            e[i][8] = "Umowa o pracę/zlecenie";
                            e[i][9] = Integer.toString(rs.getInt("salary_a"));
                            e[i][10] = Integer.toString(rs.getInt("hours"));
                            e[i][11] = "Za godzinę*";
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                    e[i][12] = "";
                    e[i][13] = "";
                }
                if(e!=null){
                    return e;
                }
                else {
                    return null;
                }
            }
        } catch (SQLException e) {

        }
        return null;
    }

        public int CountEMPROffertsWithFiltersCity(String ql, String[] a){
        String tablename = "employer_offert";
        try {
            con = getC();
            if(con==null){
                return -1;

            }else {
                 String l = ql.replace("*", "COUNT(_id)");
                 PreparedStatement stmt= con.prepareStatement(l);
                 int h= 1;
                 for (int i=0;i<a.length;i++) {
                     try {
                       if(a[i]!=null){
                           if(i==0){
                                   stmt.setString(h, a[i]); }
                           if(i==1){

                                   stmt.setInt(h, Integer.parseInt(a[i]));h++;
                              }
                           if(i==2){

                                   stmt.setInt(h, Integer.parseInt(a[i]));h++;
                                }
                           if(i==3){
                                   stmt.setInt(h, Integer.parseInt(a[i]));h++;
                               }
                           }
                     } catch (NullPointerException e) {

                     }
                 }


            }

        }catch(Exception e){
                Log.e("#DBEX EMPR ", e.toString());

        }

        return -1;
        }

        public int CountEMPROffertsByCity(String city) {
            String tablename = "employer_offert";
            try {
                con = getC();
                if (con == null) {
                    return -1;
                } else {
                    String q = "SELECT COUNT(_id) FROM " + tablename + " WHERE city=?";
                    PreparedStatement stmtl = con.prepareStatement(q);
                    stmtl.setString(1, city);
                    ResultSet rs = stmtl.executeQuery();

                    if (rs.first()) {
                        return rs.getInt(1);

                    } else {
                        return 0;
                    }
                }
            } catch (SQLException e) {
                    Log.e("#DBEX EMPR", e.toString());
            }
            return -1;
        }

}
//    private class DBEXAccount extends AsyncTask<String,String,String,String,String,String> {
//
//
//    }


