package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca;

import android.util.Log;

public class DATE {
    private int D;
    private int M;
    private int Y;


    public DATE(int D, int M, int Y){
        this.D = D;
        this.M = M;
        this.Y = Y;
    }

    public String get(){
        Log.d("DATE", ""+this.Y+"-"+this.M+"-"+this.D);
        return ""+this.Y+"-"+this.M+"-"+this.D;

    }




}
