package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Spinner;

import ExternalDB.DBEXHelpix;
import ExternalDB.EXConnection;

public class Employee_offert_make extends AppCompatActivity {
    DBEXHelpix DBEX = new DBEXHelpix();

    EXConnection connectionClass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_offert_make);

        ActionBar actionBar = getSupportActionBar();            // pobranie action bara
        actionBar.setDisplayHomeAsUpEnabled(true);


       // AutoCompleteTextView ACTV = (AutoCompleteTextView) findViewById(R.id.EMPEM_city);
        String[] cities = getResources().getStringArray(R.array.filtr_cities);
        /*ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, cities);
        ACTV.setAdapter(adapter);*/
        Spinner spinner = (Spinner) findViewById(R.id.EMPRM_cat);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.category_list, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter1);


    }

    @Override
    protected void onPause(){
        super.onPause();
    }




}
