package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;


public class Pracownik_main extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    MenuItem MI_CITY ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pracownik_main);
     /*   ActionBar actionBar = getSupportActionBar();            // pobranie action bara
        actionBar.setDisplayHomeAsUpEnabled(true);              // ustawienie strzalki na action barze [wstecz]
*/
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_employee);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_employee_offerts);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.nav_employee_open_drawer,
                R.string.nav_employee_close_drawer);
        drawer.addDrawerListener(toggle);
        toggle.syncState();




        MI_CITY = findViewById(R.id.menu_nav_employee_city);


       /* if((savedInstanceState !=null) && savedInstanceState.containsKey("textVersionColor"))
            wersja.setBackgroundColor(Color.parseColor(savedInstanceState.getString("textVersionColor")));
*/


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_search_toolbar, menu);

        return super.onCreateOptionsMenu(menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){

            default : return super.onOptionsItemSelected(item);

        }
        }
    /*@Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        int id =menuItem.getItemId();
        switch (id) {
          *//*  case R.id.nav_16:
                komunikat = "Lab. 6";
                Toast.makeText(this,komunikat,Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, Kierunki.class);
                startActivity(intent);
                break;
          *//*
            default : break;
        }
        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_employee_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }*/
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_employee_offerts);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        int id =menuItem.getItemId();
        switch (id) {
            default: break;
        }
        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_layout_employee_offerts);
        drawer.closeDrawer(GravityCompat.START);
        return true;
        }
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }






}
