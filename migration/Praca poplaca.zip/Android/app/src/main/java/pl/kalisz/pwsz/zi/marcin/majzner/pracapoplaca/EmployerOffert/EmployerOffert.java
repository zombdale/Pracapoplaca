package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca.EmployerOffert;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import ExternalDB.DBEXHelpix;
import pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca.R;

public class EmployerOffert extends AppCompatActivity {

    private DBEXHelpix DB;
    private int _idoffert;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        if(in.hasExtra("_idoffert")) {
            Log.d("#EO1", "id odebrano"+in.getIntExtra("_idoffert", -1));
            setIdOffert(in.getIntExtra("_idoffert", -1));
            setContentView(R.layout.activity_employer_offert);
            TextView name = (TextView) findViewById(R.id.employer_offert_name);
            DB = new DBEXHelpix();
            String[] records=DB.getEmployerOffertById(getIdOffert());
            name.setText(records[1]);
        }
        else {

        }

    }
        public int getIdOffert() {
        return this._idoffert;
        }

        public void setIdOffert(int s) {
            this._idoffert =s;
           }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


}




