package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca.EmployeeOffert;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import ExternalDB.DBEXHelpix;
import pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca.R;

public class EmployeeOffert extends AppCompatActivity {

    private DBEXHelpix DB;
    private int _idoffert;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        if(in.hasExtra("_idoffert")) {
            Log.d("#EO1", "id odebrano"+in.getIntExtra("_idoffert", -1));
            setIdOffert(Integer.parseInt(in.getStringExtra("_idoffert")));
            setContentView(R.layout.activity_employee_offert);
            TextView name = (TextView) findViewById(R.id.employee_offert_name);
            DB = new DBEXHelpix();
            name.setText(DB.getEmployeeOffertById(getIdOffert())[1]);
        }
        else {


        }

    }
    public int getIdOffert() {
        return this._idoffert;
    }

    public void setIdOffert(int s) {
        this._idoffert =s;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


}






