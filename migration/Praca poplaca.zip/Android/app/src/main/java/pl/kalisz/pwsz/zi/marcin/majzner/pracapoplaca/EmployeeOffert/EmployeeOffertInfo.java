package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca.EmployeeOffert;

public class EmployeeOffertInfo {
}
