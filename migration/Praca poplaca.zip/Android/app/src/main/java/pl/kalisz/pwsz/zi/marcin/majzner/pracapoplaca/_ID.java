package pl.kalisz.pwsz.zi.marcin.majzner.pracapoplaca;

import android.os.AsyncTask;

public class _ID extends AsyncTask<String, String, String> {


    @Override
    protected String doInBackground(String... strings) {
        return null;
    }
}
